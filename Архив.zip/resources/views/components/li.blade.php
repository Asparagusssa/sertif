<li style="list-style-type: none" {{ $attributes->merge(['class' => 'text-xl']) }}>{{ $slot }}</li>
