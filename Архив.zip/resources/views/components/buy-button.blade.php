<div>
    <a {{ $attributes->merge(['href' => '#', 'class' => 'text-center text-md font-bold text-gray-300 p-3 bg-blue-800 rounded-xl w-auto hover:bg-blue-700 transition duration-150 sm:text-2xl']) }} >{{ $slot }}</a>
</div>
