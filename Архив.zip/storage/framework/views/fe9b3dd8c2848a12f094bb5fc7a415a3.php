<div>
    <a <?php echo e($attributes->merge(['href' => '#', 'class' => 'text-center text-md font-bold text-gray-300 p-3 bg-blue-800 rounded-xl w-auto hover:bg-blue-700 transition duration-150 sm:text-2xl'])); ?> ><?php echo e($slot); ?></a>
</div>
<?php /**PATH /Users/lord/Herd/sertif/resources/views/components/buy-button.blade.php ENDPATH**/ ?>