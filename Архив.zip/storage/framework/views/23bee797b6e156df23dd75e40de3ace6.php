<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-10">
        <section class="p-6 bg-gray-800 border-t border-white flex lg:flex-row flex-col items-center">
            <div class="w-1/3 flex justify-center">
                <img src="<?php echo e(Vite::asset('/resources/images/head.webp')); ?>" alt="logo" class="h-[300px] lg:block hidden">
            </div>
            <div class="lg:w-2/3 w-full flex flex-col justify-center items-center p-6">
                <h1 class="font-bold text-5xl text-center mb-6 text-white">Бизнес сертификация</h1>
                <p class="text-center text-2xl font-medium text-gray-300 mb-3">Сертификация онлайн-магазина - это первый шаг к успеху!</p>
                <p class="text-center text-xl text-gray-300 mb-6">Получите официальный документ, подтверждающий соответствие
                    вашего сайта требованиям законодательства, и повысьте доверие к вашему бренду.</p>
                <?php if (isset($component)) { $__componentOriginalb93c81cf0f33791f24e220bc848d38cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb93c81cf0f33791f24e220bc848d38cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buy-button','data' => ['href' => '/certification']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buy-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/certification']); ?>Посмотреть сертификаты <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb93c81cf0f33791f24e220bc848d38cb)): ?>
<?php $attributes = $__attributesOriginalb93c81cf0f33791f24e220bc848d38cb; ?>
<?php unset($__attributesOriginalb93c81cf0f33791f24e220bc848d38cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb93c81cf0f33791f24e220bc848d38cb)): ?>
<?php $component = $__componentOriginalb93c81cf0f33791f24e220bc848d38cb; ?>
<?php unset($__componentOriginalb93c81cf0f33791f24e220bc848d38cb); ?>
<?php endif; ?>
            </div>
        </section>
        <section class="mx-auto max-w-7xl pb-6 px-6 lg:px-8 lg:flex">
            <div class="w-full space-y-6 lg:w-1/2 lg:text-start text-center">
                <h1 class="text-3xl font-bold">Для чего нужен этот сайт?</h1>
                <ul class="list-disc space-y-2">
                    <?php if (isset($component)) { $__componentOriginal3226da848e43d6bd511b27fd7a014616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3226da848e43d6bd511b27fd7a014616 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.li','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('li'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Удобно найти все сервисы для получения сертификата <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $attributes = $__attributesOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__attributesOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $component = $__componentOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__componentOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal3226da848e43d6bd511b27fd7a014616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3226da848e43d6bd511b27fd7a014616 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.li','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('li'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Сравнить цены на сертификаты <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $attributes = $__attributesOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__attributesOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $component = $__componentOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__componentOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal3226da848e43d6bd511b27fd7a014616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3226da848e43d6bd511b27fd7a014616 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.li','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('li'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Выбрать подходящий сервис для получения сертификата <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $attributes = $__attributesOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__attributesOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $component = $__componentOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__componentOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal3226da848e43d6bd511b27fd7a014616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3226da848e43d6bd511b27fd7a014616 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.li','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('li'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Найти контактные данные сервиса <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $attributes = $__attributesOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__attributesOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3226da848e43d6bd511b27fd7a014616)): ?>
<?php $component = $__componentOriginal3226da848e43d6bd511b27fd7a014616; ?>
<?php unset($__componentOriginal3226da848e43d6bd511b27fd7a014616); ?>
<?php endif; ?>
                </ul>
                <?php if (isset($component)) { $__componentOriginalb93c81cf0f33791f24e220bc848d38cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb93c81cf0f33791f24e220bc848d38cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buy-button','data' => ['href' => '/certification']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buy-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/certification']); ?>Посмотреть сертификаты <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb93c81cf0f33791f24e220bc848d38cb)): ?>
<?php $attributes = $__attributesOriginalb93c81cf0f33791f24e220bc848d38cb; ?>
<?php unset($__attributesOriginalb93c81cf0f33791f24e220bc848d38cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb93c81cf0f33791f24e220bc848d38cb)): ?>
<?php $component = $__componentOriginalb93c81cf0f33791f24e220bc848d38cb; ?>
<?php unset($__componentOriginalb93c81cf0f33791f24e220bc848d38cb); ?>
<?php endif; ?>
            </div>
            <div class="w-1/2 flex justify-center items-center">
                <img src="<?php echo e(Vite::asset('/resources/images/section1.webp')); ?>" alt="logo" class="h-[300px] lg:block hidden">
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/lord/Herd/sertif/resources/views/home.blade.php ENDPATH**/ ?>