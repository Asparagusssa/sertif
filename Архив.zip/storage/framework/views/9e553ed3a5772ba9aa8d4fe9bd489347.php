<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['certification']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['certification']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="relative flex-grow text-center p-2 sm:p-5 rounded-xl bg-white/50 border-2 hover:scale-105 transition-transform duration-300 <?php echo e($certification->paid ? 'border-orange-600' : 'border-green-600'); ?>">
    <p class="font-bold text-2xl hyphens-auto"><?php echo e($certification->name); ?></p>
    <?php if($certification->paid): ?>
        <p class="text-orange-600 text-xl">Цена: <?php echo e(number_format($certification->price, 0, ',')); ?> RUB</p>
    <?php else: ?>
        <p class="text-green-600 text-xl">Бесплатно</p>
    <?php endif; ?>
    <div class="">
        <p class="text-xs hyphens-auto"><?php echo e($certification->url); ?></p>
    </div>
    <a class="absolute inset-0" href="<?php echo e($certification->url); ?>"></a>
</div>
<?php /**PATH /Users/lord/Herd/sertif/resources/views/components/certification-card.blade.php ENDPATH**/ ?>